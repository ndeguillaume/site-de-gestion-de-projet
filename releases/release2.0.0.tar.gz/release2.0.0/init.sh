#!/bin/bash
cp sample.env .env
docker-compose up -d
