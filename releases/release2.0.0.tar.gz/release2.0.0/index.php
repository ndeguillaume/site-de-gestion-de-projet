<?php

  header('Location: /models/issue/views/Backlog.php');
  exit();
