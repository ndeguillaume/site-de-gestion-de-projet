<table>
    <thead>
        <tr>
            <th colspan="3">Release</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Version</td>
            <td>Date</td>
            <td>Issues réalisées</td>
            <td>Release</td>
        </tr>
        <tr>
            <td>1.0.0</td>
            <td>13/11/2020</td>
            <td>5, 6, 7, 8, 9, 10, 11, 12, 13, 18, 19, 20, 21, 23</td>
            <td>Pas encore</td>
        </tr>
            <tr>
            <td>2.0.0</td>
            <td>26/11/2020</td>
            <td>24, 25, 26, 27, 28, 29, 30, 32, 33</td>
            <td><a href='release2.0.0.zip'>Release2.0.0</a></td>
        </tr>
    </tbody>
</table>