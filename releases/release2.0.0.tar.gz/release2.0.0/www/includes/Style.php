<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
<!--bootstrap datetimepicker css-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css">
<script src="https://kit.fontawesome.com/14ad046d7e.js" crossorigin="anonymous"></script>
<link rel="stylesheet" href="../../../public/css/style.css">
