<div class="test-scenario-information hidden" >
   <div>
      <h3 class="test-scenario-information-id">Scénario <span class="test-scenario-id"></span></h3>
   </div>
   <div>
      <h3>Titre</h3>
      <textarea maxlength="255" id="title" class="test-scenario-information-title" onkeydown="textAreaAdjust(this)"></textarea>
   </div>
   <div>
      <h3>Description</h3>
      <textarea maxlength="1000" id="description" class="test-scenario-information-description" onkeydown="textAreaAdjust(this)" style="overflow:hidden">></textarea>
   </div>
   <div class="button-wrapper">
   </div>
</div>  